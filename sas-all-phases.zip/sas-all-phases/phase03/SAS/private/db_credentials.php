<?php

define("DB_SERVER","localhost");
define("DB_USER","aachipsc_webuser");
define("DB_PASS","12345Bb");
define("DB_NAME","aachipsc_salamanders");