<?php require_once('../../private/initialize.php'); 
include(SHARED_PATH . '/salamander-header.php');
echo "<h1>Stub for New Salamander</h1>";

include(SHARED_PATH . '/salamander-footer.php'); ?>
