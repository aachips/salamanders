<?php include_once('../private/initialize.php');

echo "<p>Private Path: ".PRIVATE_PATH."</p>";
echo "<p>Public Path: ".PUBLIC_PATH."</p>";
echo "<p>Shared Path: ".SHARED_PATH."</p>";
echo "<p>Project Path: ".PROJECT_PATH."</p>";
echo "<p>Document Root: ".WWW_ROOT."</p>";
echo $public_end;
echo $doc_root;
